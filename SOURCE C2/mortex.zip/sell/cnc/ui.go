package main

import (
	"fmt"
	"net"
	"regexp"
	"strings"
	"time"
)

var ansiRegexp = regexp.MustCompile(`\x1b\[[0-9;]*[a-zA-Z]`)

var lineswelcome = []string{
	"\033[38;5;15m     _                      \033[38;5;125m_______                      \033[38;5;15m_\r\n",
    "\033[38;5;15m  _dMMMb._              \033[38;5;125m.adOOOOOOOOOba.              \033[38;5;15m_,dMMMb_\r\n",
    "\033[38;5;15m dP'  ~YMMb            \033[38;5;125mdOOOOOOOOOOOOOOOb            \033[38;5;15maMMP~  `Yb\r\n",
    "\033[38;5;15m V      ~\"Mb          \033[38;5;125mdOOOOOOOOOOOOOOOOOb          \033[38;5;15mdM\"~      V\r\n",
    "\033[38;5;15m          `Mb.       \033[38;5;125mdOOOOOOOOOOOOOOOOOOOb       \033[38;5;15m,dM'\r\n",
    "\033[38;5;15m           `YMb._   \033[38;5;125m|OOOOOOOOOOOOOOOOOOOOO|   \033[38;5;15m_,dMP'\r\n",
    "\033[38;5;15m      __     `YMMM| \033[38;5;125mOP'~\"YOOOOOOOOOOOP\"~`YO \033[38;5;15m|MMMP'     __\r\n",
    "\033[38;5;15m    ,dMMMb.     ~~' \033[38;5;125mOO     `YOOOOOP'     OO \033[38;5;15m`~~     ,dMMMb.\r\n",
    "\033[38;5;15m _,dP~  `YMba_      \033[38;5;125mOOb      `OOO'      dOO      \033[38;5;15m_aMMP'  ~Yb.\r\n",
    "\033[38;5;15m             `YMMMM\\\033[38;5;125m`OOOo     OOO     oOOO\033[38;5;15m'/MMMMP'\r\n",
    "\033[38;5;15m     ,aa.     `~YMMb \033[38;5;125m`OOOb._,dOOOb._,dOOO\033[38;5;15m'dMMP~'       ,aa.\r\n",
    "\033[38;5;15m   ,dMYYMba._         \033[38;5;125m`OOOOOOOOOOOOOOOOO'          \033[38;5;15m_,adMYYMb.\r\n",
    "\033[38;5;15m  ,MP'   `YMMba._      \033[38;5;125mOOOOOOOOOOOOOOOOO       \033[38;5;15m_,adMMP'   `YM.\r\n",
    "\033[38;5;15m  MP'        ~YMMMba._ \033[38;5;125mYOOOOPVVVVVYOOOOP  \033[38;5;15m_,adMMMMP~       `YM\r\n",
    "\033[38;5;15m  YMb           ~YMMMM\\\033[38;5;125m`OOOOI`````IOOOOO'\033[38;5;15m/MMMMP~           dMP\r\n",
    "\033[38;5;15m   `Mb.           `YMMMb\033[38;5;125m`OOOI,,,,,IOOOO'\033[38;5;15mdMMMP'           ,dM'\r\n",
    "\033[38;5;15m     `'                  \033[38;5;125m`OObNNNNNdOO'                   \033[38;5;15m`'\r\n",
    "\033[38;5;15m                           \033[38;5;125m`~OOOOO~'\r\n",
    "                                        \033[38;5;196mM\033[38;5;201mO\033[38;5;206mR\033[38;5;93mT\033[38;5;99mE\033[38;5;135mX\033[0m\r\n",
    "\033[0m\r\n",
}

var linesbanner = []string{
	"\033[8;24;80t",
	"\033[2J\033[1;1H",
	"\033[0m\r\n",
	"   \033[38;5;15m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢤⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀\r\n",
	"   \033[38;5;15m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⡾⠿⢿⡀⠀⠀⠀⠀\033[38;5;125m⣠⣶⣿⣷⠀⠀⠀⠀\r\n",
	"   \033[38;5;15m⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⣦⣴⣿⡋⠀⠀⠈⢳⡄⠀\033[38;5;125m⢠⣾⣿⠁⠈⣿⡆⠀⠀⠀\r\n",
	"",
	"   \033[38;5;15m⠀⠀⠀⠀⠀⣠⣾⡿⠋⠁\033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⣰⣏⢻⣿⣿⡆⠀⠸⣿⠀⠀⠀\r\n",
	"   \033[38;5;15m⠀⠀⠀⢀⣴⠟⠁  \033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣆⠹⣿⣷⠀⢘⣿⠀⠀⠀\r\n",
	"   \033[38;5;15m⠀⠀⢀⡾⠁\033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⣿⣿⠋⠉⠛⠂⠹⠿⣲⣿⣿⣧⠀⠀\r\n",
	"   \033[38;5;15m⠀⢠⠏\033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣿⣿⣿⣷⣾⣿⡇⢀⠀⣼⣿⣿⣿⣧⠀\r\n",
	"   \033[38;5;15m⠰⠃\033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⡘⢿⣿⣿⣿⠀\r\n",
	"   \033[38;5;15m⠁\033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⣷⡈⠿⢿⣿⡆\r\n",
	"   \033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠛⠁⢙⠛⣿⣿⣿⣿⡟⠀⡿⠀⠀⢀⣿⡇\r\n",
	"   \033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⣶⣤⣉⣛⠻⠇⢠⣿⣾⣿⡄⢻⡇\r\n",
	"   \033[38;5;125m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣦⣤⣾⣿⣿⣿⣿⣆⠁\r\n",
	"\033[0m\r\n",
}

var linesmethods = []string{
	"\033[8;24;80t", "\033[2J\033[1;1H\r\n", "\033[0m\r\n",
	"   \033[38;5;125mMethods\x1b[38;5;231m:\033[0m\r\n",
	"     \033[38;5;15m.tcpflood   \033[38;5;125m| \033[38;5;15mSimple syn+ack flood to exhaust server resources\033[38;5;125m.\r\n",
	"     \033[38;5;15m.tcpboom    \033[38;5;125m| \033[38;5;15mEnhanced TCP flood with crafted TCP options for bypass\033[38;5;125m.\r\n",
	"     \033[38;5;15m.tcpkiller  \033[38;5;125m| \033[38;5;15mSyn+ack+rst packets to disrupt active TCP connections\033[38;5;125m.\r\n",
	"     \033[38;5;15m.tcpbypass  \033[38;5;125m| \033[38;5;15mRandomized tcp flag flood to bypass firewall\033[38;5;125m.\r\n",
	"     \033[38;5;15m.ovhtcp     \033[38;5;125m| \033[38;5;15mGRE-encapsulated TCP flood with spoofed IPs\033[38;5;125m.\r\n",
	"     \033[38;5;15m.udpflood   \033[38;5;125m| \033[38;5;15mPlain udp flood with random or static payload\033[38;5;125m.\r\n",
	"     \033[38;5;15m.udpbypass  \033[38;5;125m| \033[38;5;15mRandom length udp flood to bypass basic filtering\033[38;5;125m.\r\n",
	"     \033[38;5;15m.vse        \033[38;5;125m| \033[38;5;15mValve Source Engine query flood to disrupt game servers\033[38;5;125m.\r\n",
	"     \033[38;5;15m.discord    \033[38;5;125m| \033[38;5;15mUdp flood using Discord payload to mimic voice traffic\033[38;5;125m.\r\n",
	"     \033[38;5;15m.http       \033[38;5;125m| \033[38;5;15mSimple http flood optimized for higher requests\033[38;5;125m.\r\n",
	"     \033[38;5;15m.icmpflood  \033[38;5;125m| \033[38;5;15mSimple icmp flood to exhaust server resources\033[38;5;125m.\r\n",
	"\033[0m\r\n",
}

var lineshelpadmin = []string{
	"\033[8;24;80t", "\033[2J\033[1;1H\r\n", "\033[0m\r\n",
	"   \033[38;5;125mCommands\x1b[38;5;231m:\033[0m\r\n",
	"     \033[38;5;15mHelp        \033[38;5;125m| \033[38;5;15mList of available commands\033[38;5;125m.\r\n",
	"     \033[38;5;15mMethods     \033[38;5;125m| \033[38;5;15mList of available methods\033[38;5;125m.\r\n",
	"     \033[38;5;15mClear       \033[38;5;125m| \033[38;5;15mClear screen\033[38;5;125m.\r\n",
	"     \033[38;5;15mOngoing     \033[38;5;125m| \033[38;5;15mShowing attacks currently in running\033[38;5;125m.\r\n",
	"     \033[38;5;15mPlan        \033[38;5;125m| \033[38;5;15mFor showing your plan\033[38;5;125m.\r\n",
	"     \033[38;5;15mStop        \033[38;5;125m| \033[38;5;15mFor stoping all attacks\033[38;5;125m.\r\n",
	"     \033[38;5;15mAttacks     \033[38;5;125m| \033[38;5;15mFor enable/disable attacks\033[38;5;125m.\r\n",
	"     \033[38;5;15mAdduser     \033[38;5;125m| \033[38;5;15mFor adding user\033[38;5;125m.\r\n",
	"     \033[38;5;15mRemoveuser  \033[38;5;125m| \033[38;5;15mFor removing user\033[38;5;125m.\r\n",
	"     \033[38;5;15mUserlist    \033[38;5;125m| \033[38;5;15mShowing all users\033[38;5;125m.\r\n",
	"     \033[38;5;15mLogs        \033[38;5;125m| \033[38;5;15mFor clearing logs\033[38;5;125m.\r\n",
	"     \033[38;5;15mExit        \033[38;5;125m| \033[38;5;15mFor logging out\033[38;5;125m.\r\n",
	"\033[0m\r\n",
}

var lineshelp = []string{
	"\033[8;24;80t", "\033[2J\033[1;1H\r\n", "\033[0m\r\n",
	"   \033[38;5;125mCommands\x1b[38;5;231m:\033[0m\r\n",
	"     \033[38;5;15mHelp        \033[38;5;125m| \033[38;5;15mList of available commands\033[38;5;125m.\r\n",
	"     \033[38;5;15mMethods     \033[38;5;125m| \033[38;5;15mList of available methods\033[38;5;125m.\r\n",
	"     \033[38;5;15mClear       \033[38;5;125m| \033[38;5;15mClear screen\033[38;5;125m.\r\n",
	"     \033[38;5;15mOngoing     \033[38;5;125m| \033[38;5;15mShowing attacks currently in running\033[38;5;125m.\r\n",
	"     \033[38;5;15mPlan        \033[38;5;125m| \033[38;5;15mFor showing your plan\033[38;5;125m.\r\n",
	"     \033[38;5;15mExit        \033[38;5;125m| \033[38;5;15mFor logging out\033[38;5;125m.\r\n",
	"\033[0m\r\n",
}

func Print(conn net.Conn, which string) {
	var lines []string
	switch which {
	case "help":
		lines = lineshelp
	case "helpadmin":
		lines = lineshelpadmin
	case "methods":
		lines = linesmethods
	case "banner":
		linesbanner[6] = fmt.Sprintf("   \033[38;5;15m⠀⠀⠀⠀⠀⠀⠀⣰⣿⣿⠿⠛⠉⠉⠁⠀⠀⠀⠹⡄\033[38;5;125m⣿⣿⣿⠀⠀⢹⡇     \033[38;5;196mM\033[38;5;201mo\033[38;5;206mr\033[38;5;93mt\033[38;5;99me\033[38;5;135mx \033[38;5;15m%s\r\n", config.Version)
		lines = linesbanner
    case "welcome":
		lines= lineswelcome
	}
	for _, line := range lines {
		conn.Write([]byte(line))
		time.Sleep(30 * time.Millisecond)
	}
}

func PrintPlan(conn net.Conn, u *UserInfo) {
	if u == nil {
		conn.Write([]byte("\x1b[1;31mError fetching plan information.\033[0m\r\n"))
		return
	}

	expiryStr := calculateExpiry(u.last_paid, u.intvl)
	adminStr := "No"
	if u.admin == 1 {
		adminStr = "Yes"
	}
	apiStr := "No"
	if u.api_access == 1 {
		apiStr = "Yes"
	}

	apiKey, err := database.GetUserAPIKey(u.username)
	if err != nil {
		apiKey = "N/A"
	}

	lines := []string{
		"\r\n",
		fmt.Sprintf(" \x1b[38;5;231m[ \033[38;5;125mAccount Info \x1b[38;5;231m]\r\n"),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mUsername \x1b[39m\033[38;5;125m··········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", u.username),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mMax Bots \x1b[39m\033[38;5;125m··········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%d \x1b[38;5;231m]\r\n", u.maxBots),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mDuration \x1b[39m\033[38;5;125m··········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%d \x1b[38;5;231m]\r\n", u.duration_limit),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mCooldown \x1b[39m\033[38;5;125m··········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%d \x1b[38;5;231m]\r\n", u.cooldown),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mExpired \x1b[39m\033[38;5;125m············ \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", expiryStr),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mAdmin \x1b[39m\033[38;5;125m·············· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", adminStr),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mApi Access \x1b[39m\033[38;5;125m········· \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", apiStr),
		fmt.Sprintf("  \033[38;5;125m║\x1b[39m  \x1b[38;5;231mApi Key \x1b[39m\033[38;5;125m············ \x1b[38;5;231m[ \x1b[39m\033[38;5;125m%s \x1b[38;5;231m]\r\n", apiKey),
		"\r\n",
	}

	for _, line := range lines {
		conn.Write([]byte(line))
		time.Sleep(30 * time.Millisecond)
	}
}

func printTable(conn net.Conn, columns []string, dataRows [][]string) {
	maxVisibleLengths := make([]int, len(columns))
	for i, header := range columns {
		maxVisibleLengths[i] = visibleLength(header)
	}
	for _, row := range dataRows {
		for i, cell := range row {
			cellLen := visibleLength(cell)
			if cellLen > maxVisibleLengths[i] {
				maxVisibleLengths[i] = cellLen
			}
		}
	}

	currentSessionWidth := 80
	totalTableWidth := getTotalTableWidth(maxVisibleLengths)
	if totalTableWidth > currentSessionWidth {
		conn.Write([]byte(fmt.Sprintf("\x1b[8;24;%dt", totalTableWidth)))
		time.Sleep(100 * time.Millisecond)
	}

	printHLine := func(left, middle, right string) {
		conn.Write([]byte("\x1b[38;5;231m" + left))
		for i, maxLen := range maxVisibleLengths {
			if i > 0 {
				conn.Write([]byte(middle))
			}
			conn.Write([]byte(strings.Repeat("═", maxLen+2)))
		}
		conn.Write([]byte("\x1b[38;5;231m" + right + "\r\n"))
	}

	printHLine("╔", "╦", "╗")

	conn.Write([]byte("\x1b[38;5;231m║"))
	for i, header := range columns {
		visibleLen := visibleLength(header)
		padding := maxVisibleLengths[i] - visibleLen
		conn.Write([]byte(" " + header + strings.Repeat(" ", padding) + " \x1b[38;5;231m║"))
	}
	conn.Write([]byte("\r\n"))

	printHLine("╠", "╬", "╣")

	for _, row := range dataRows {
		conn.Write([]byte("\x1b[38;5;231m║"))
		for i, cell := range row {
			visibleLen := visibleLength(cell)
			padding := maxVisibleLengths[i] - visibleLen
			conn.Write([]byte(" " + cell + strings.Repeat(" ", padding) + " \x1b[38;5;231m║"))
		}
		conn.Write([]byte("\r\n"))
	}

	printHLine("╚", "╩", "╝")
}

func visibleLength(s string) int {
	return len(ansiRegexp.ReplaceAllString(s, ""))
}

func getTotalTableWidth(columnWidths []int) int {
	totalWidth := 1
	for _, w := range columnWidths {
		totalWidth += 2 + w + 1
	}
	return totalWidth
}
