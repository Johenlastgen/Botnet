#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <arpa/inet.h>

static uint32_t table_key = 0x5FF176B1;

void *xor_decrypt(void *data, int len);

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <type> <hex_data>\n", argv[0]);
        fprintf(stderr, "Types: string, ip, uint32, uint16, uint8, bool\n");
        fprintf(stderr, "hex_data: Hex string (e.g., \\xDE\\xAD\\xBE\\xEF)\n");
        return 1;
    }

    char *type = argv[1];
    char *hex_input = argv[2];
    size_t hex_len = strlen(hex_input);
    size_t data_len = 0;

    if (hex_len % 4 != 0 || hex_len < 4) {
        fprintf(stderr, "Invalid hex string format. Use \\xHH\\xHH...\n");
        return 1;
    }

    data_len = hex_len / 4;
    unsigned char *data = malloc(data_len);
    if (!data) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }

    for (size_t i = 0; i < data_len; i++) {
        if (hex_input[i * 4] != '\\' || hex_input[i * 4 + 1] != 'x') {
            fprintf(stderr, "Invalid hex format at position %zu\n", i * 4);
            free(data);
            return 1;
        }
        int byte;
        if (sscanf(hex_input + i * 4 + 2, "%2x", &byte) != 1) {
            fprintf(stderr, "Invalid hex value at position %zu\n", i * 4);
            free(data);
            return 1;
        }
        data[i] = (unsigned char)byte;
    }

    unsigned char *decrypted = xor_decrypt(data, data_len);
    if (!decrypted) {
        fprintf(stderr, "Decryption failed\n");
        free(data);
        return 1;
    }

    printf("Decrypted %zu bytes:\n", data_len);
    if (strcmp(type, "string") == 0) {
        printf("String: %s\n", decrypted);
    } else if (strcmp(type, "ip") == 0) {
        if (data_len != sizeof(uint32_t)) {
            fprintf(stderr, "Invalid length for IP (%zu bytes, expected %zu)\n", 
                    data_len, sizeof(uint32_t));
            free(data);
            free(decrypted);
            return 1;
        }
        struct in_addr ip_addr;
        ip_addr.s_addr = *(uint32_t *)decrypted;
        printf("IP: %s\n", inet_ntoa(ip_addr));
    } else if (strcmp(type, "uint32") == 0) {
        if (data_len != sizeof(uint32_t)) {
            fprintf(stderr, "Invalid length for uint32 (%zu bytes, expected %zu)\n", 
                    data_len, sizeof(uint32_t));
            free(data);
            free(decrypted);
            return 1;
        }
        printf("uint32: %u\n", ntohl(*(uint32_t *)decrypted));
    } else if (strcmp(type, "uint16") == 0) {
        if (data_len != sizeof(uint16_t)) {
            fprintf(stderr, "Invalid length for uint16 (%zu bytes, expected %zu)\n", 
                    data_len, sizeof(uint16_t));
            free(data);
            free(decrypted);
            return 1;
        }
        printf("uint16: %u\n", ntohs(*(uint16_t *)decrypted));
    } else if (strcmp(type, "uint8") == 0) {
        if (data_len != sizeof(uint8_t)) {
            fprintf(stderr, "Invalid length for uint8 (%zu bytes, expected %zu)\n", 
                    data_len, sizeof(uint8_t));
            free(data);
            free(decrypted);
            return 1;
        }
        printf("uint8: %u\n", decrypted[0]);
    } else if (strcmp(type, "bool") == 0) {
        if (data_len != sizeof(char)) {
            fprintf(stderr, "Invalid length for bool (%zu bytes, expected %zu)\n", 
                    data_len, sizeof(char));
            free(data);
            free(decrypted);
            return 1;
        }
        printf("bool: %s\n", decrypted[0] ? "true" : "false");
    } else {
        fprintf(stderr, "Unknown type: %s\n", type);
        free(data);
        free(decrypted);
        return 1;
    }

    free(data);
    free(decrypted);
    return 0;
}

void *xor_decrypt(void *_buf, int len) {
    unsigned char *buf = (unsigned char *)_buf;
    unsigned char *out = malloc(len);
    if (!out) return NULL;

    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for (int i = 0; i < len; i++) {
        char tmp = buf[i] ^ k4;
        tmp ^= k3;
        tmp ^= k2;
        tmp ^= k1;
        out[i] = tmp;
    }

    return out;
}