#ifndef LOCKER_H
#define LOCKER_H

void watcher_init(void);
void disable_commands(void);

#endif
